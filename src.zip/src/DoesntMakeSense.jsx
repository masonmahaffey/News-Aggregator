class Stocks extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
		stocks: []
    }
    this.componentDidMount = this.componentDidMount.bind(this);
  }  

  componentDidMount() {
	$.getJSON(stockUrl, (stockData) =>{
		console.log(stockData)
		this.setState({
			stocks: stockData
		})
	});		
  }

  render() {
  	console.log(this.state.stocks.quote)
    return(
		<div>
			<Stock stocks={this.state.stocks.quote} />					
		</div>
		)
  	}
}


class Stock extends React.Component{
	render(){
		return(
			<div>
				{this.props.stocks.map(function(stock, index){
					return(
						<div key={index}>
							{stock.symbol}
						</div>
					)
				})}
			</div>
		)
	}
}