import React from 'react';
import './business.css';
import $ from 'jquery'
// const newsApiKey = '275258a3655c449ba4907833f5baf08b';
// const apiMain = 'https://newsapi.org/v1/articles?source=';	
// const apiTail = '&apiKey='
var symbol = 'AAPL+GOOG+BAC+FB+TSLA+WPX+WFC+RAD+FCX+F+GE+JCP+JPM+VALE+FCAU+FTI+T+S'
var stockFront = 'http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.quotes%20where%20symbol%20in%20("'
var stockTail = '")%0A%09%09&env=http%3A%2F%2Fdatatables.org%2Falltables.env&format=json'
var stockUrl = stockFront + symbol + stockTail

// function runJSON1(){
// 	var url = `http://query.yahooapis.com/v1/public/yql?
// 	q=select%20*%20from%20yahoo.finance.quotes%20where%20symbol%20in%20
// 	("${symbol}")%0A%09%09&env=http%3A%2F%2Fdatatables.org%2Falltables.env&format=json`;
// 	$.getJSON(url, function(stockData){
// 		var stockInfo = stockData.query.results.quote;
// 		if(stockData.query.count == 1){
// 			var htmlToPlot = buildStockRow(stockInfo);
// 			$('#stock-body').html(htmlToPlot);				
// 		}else{
// 			$('#stock-body').html("");
// 			for(let i = 0; i < stockInfo.length; i++){
// 				var htmlToPlot = buildStockRow(stockInfo[i]);
// 				$('#stock-body').append(htmlToPlot);
// 			}
// 		}
// 	});	
// }
// newHTML += '<tr>';
// 		newHTML += '<td>'+(stock.Symbol).toUpperCase() +'</td>';
// 		newHTML += '<td>'+stock.Name+'</td>';
// 		newHTML += '<td>'+stock.Ask+'</td>';
// 		newHTML += '<td>'+stock.Bid+'</td>';
// 		newHTML += '<td class="'+classChange+'">'+stock.Change+'</td>';
// 		newHTML += '<td>'+timeStamp+'</td>';
// 	newHTML += '</tr>';

class Stocks extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
		stocks: []
    }
    this.componentDidMount = this.componentDidMount.bind(this);
  }  

  componentDidMount() {
	$.getJSON(stockUrl, (stockData) =>{
		var stockArr = stockData.query.results.quote
		var stockArrMin = []
		for(let i = 0; i < stockArr.length; i++){
			if((stockArr[i].Ask!==null)){
			var stockSymbol = stockArr[i].symbol + " " + stockArr[i].Ask
			stockArrMin.push(stockSymbol)}
		}
		this.setState({
			stocks: stockArrMin
		})
	});		
  }

  render() {
  	console.log(this.state.stocks)
  	// var stockArr = this.state.stocks
    return(
		<div>				
			{this.state.stocks.map(function(stock, index){
				return(
					<div key={index}>
						{stock}
					</div>
				)
			})}
		</div>
		)
  	}
}


class Stock extends React.Component{
	render(){
		
		return(
			<div>
				
				
				
				
			</div>
		)
	}
}

// class Child extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = {
// 		articlesArray: []
//     }
//     this.componentDidMount = this.componentDidMount.bind(this);
//   }  

//   componentDidMount() {
//     var apiSource = 'the-economist';
// 		var url = apiMain + apiSource + apiTail + newsApiKey;
// 		$.getJSON(url, (newsData) =>{
// 			console.log(newsData)
// 			this.setState({
// 				articlesArray: newsData.articles
// 			})
// 		});		
//   }

//   render() {
//     return(
// 		<div className='c1c1'>
// 			<Component1child1grandchild articles={this.state.articlesArray} />
// 		</div>
// 		)
    
//   }
// }


// var Component1child1grandchild = React.createClass({
// 	render: function(){
// 		// console.log(this.props.articles)
// 		return(
// 			<div className='scrollingNews hidden-xs'>
// 				{this.props.articles.map(function(article, index){
// 					return(
// 						<div key={index} style={{fontSize:18, padding:15, display: 'inline-block'}}>
// 							{article.description}
// 						</div>
// 					)	
// 				})}
// 			</div>
// 		)
// 	}
// })


class Business extends React.Component{
	render() {
		return(
			<div style={{backgroundColor:'yellow'}}>
				<Stocks />
			</div>
		)		
	}
}


export default Business;
