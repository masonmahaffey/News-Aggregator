import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';
import { Router, Route, hashHistory, IndexRoute } from 'react-router'
import General from './General.jsx'
import Entertainment from './Entertainment.jsx'
import Sports from './Sports.jsx'
import Business from './Business.jsx'

ReactDOM.render(
	<Router history={hashHistory}>
		<Route path="/" component={App} >
			<IndexRoute component={General} />
			<Route path="entertainment" component={Entertainment} />
			<Route path="sports" component={Sports} />
			<Route path="business" component={Business} />
		</Route>
	</Router>,	
  document.getElementById('root')
);
